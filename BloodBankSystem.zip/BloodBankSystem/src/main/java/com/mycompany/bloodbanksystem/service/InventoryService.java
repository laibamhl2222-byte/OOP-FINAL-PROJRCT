package com.mycompany.bloodbanksystem.service;

import com.mycompany.bloodbanksystem.model.InventoryItem;
import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.util.FileUtil;

import java.time.LocalDate;
import java.util.*;

public class InventoryService {

    private final String FILE = "inventory.txt";
    private final String[] BLOOD_GROUPS = 
            {"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"};

    // Convert InventoryItem → CSV
    private String toCSV(InventoryItem item) {
        return item.getId() + "," +
               item.getBloodGroup() + "," +
               item.getUnits() + "," +
               item.getAddedOn() + "," +
               item.getNotes();
    }

    private InventoryItem fromCSV(String line) {
        String[] a = line.split(",", -1); // keep empty fields
        return new InventoryItem(
                a.length > 0 ? a[0] : UUID.randomUUID().toString(),
                a.length > 1 ? a[1] : "O+",
                a.length > 2 ? Integer.parseInt(a[2]) : 0,
                a.length > 3 ? a[3] : LocalDate.now().toString(),
                a.length > 4 ? a[4] : ""
        );
    }

    // -----------------------
    // Fetch Methods
    // -----------------------
    public List<InventoryItem> getAll() {
        List<String> lines = FileUtil.readFileToList(FILE);
        List<InventoryItem> items = new ArrayList<>();

        if (lines.isEmpty()) {
            for (String bg : BLOOD_GROUPS) {
                InventoryItem i = new InventoryItem(
                        UUID.randomUUID().toString(),
                        bg,
                        0,
                        LocalDate.now().toString(),
                        ""
                );
                items.add(i);
                lines.add(toCSV(i));
            }
            FileUtil.writeListToFile(FILE, lines);
            return items;
        }

        for (String s : lines) items.add(fromCSV(s));

        return items;
    }

    public InventoryItem getById(String id) {
        for (InventoryItem i : getAll()) {
            if (i.getId().equals(id)) return i;
        }
        return null;
    }

    public InventoryItem getByBloodGroup(String bloodGroup) {
        for (InventoryItem i : getAll()) {
            if (i.getBloodGroup().equalsIgnoreCase(bloodGroup))
                return i;
        }
        return null;
    }

    // -----------------------
    // CRUD
    // -----------------------
    public void addItem(InventoryItem item, String adminUser) {
        List<InventoryItem> list = getAll();
        boolean exists = false;

        for (InventoryItem i : list) {
            if (i.getBloodGroup().equalsIgnoreCase(item.getBloodGroup())) {
                i.setUnits(i.getUnits() + item.getUnits());
                i.setNotes(item.getNotes());
                updateItem(i, adminUser);
                exists = true;
                break;
            }
        }

        if (!exists) {
            List<String> csv = new ArrayList<>();
            for (InventoryItem i : list) csv.add(toCSV(i));
            csv.add(toCSV(item));
            FileUtil.writeListToFile(FILE, csv);

            new LogService().addLog(
                    new LogEntry(adminUser,
                            "ADD INVENTORY",
                            "New Blood Group Added: " + item.getBloodGroup())
            );
        }
    }

    public void updateItem(InventoryItem updated, String adminUser) {
        List<String> list = FileUtil.readFileToList(FILE);
        List<String> newList = new ArrayList<>();

        for (String s : list) {
            InventoryItem i = fromCSV(s);
            if (i.getId().equals(updated.getId()))
                newList.add(toCSV(updated));
            else
                newList.add(s);
        }

        FileUtil.writeListToFile(FILE, newList);

        new LogService().addLog(new LogEntry(
                adminUser,
                "UPDATE INVENTORY",
                "Updated Group: " + updated.getBloodGroup() +
                        ", Units: " + updated.getUnits()
        ));
    }

    public void deleteItem(String id, String adminUser) {
        InventoryItem item = getById(id);

        List<String> list = FileUtil.readFileToList(FILE);
        list.removeIf(s -> s.startsWith(id + ","));
        FileUtil.writeListToFile(FILE, list);

        new LogService().addLog(new LogEntry(
                adminUser,
                "DELETE INVENTORY",
                "Deleted Group: " + (item != null ? item.getBloodGroup() : "UNKNOWN")
        ));
    }
}
