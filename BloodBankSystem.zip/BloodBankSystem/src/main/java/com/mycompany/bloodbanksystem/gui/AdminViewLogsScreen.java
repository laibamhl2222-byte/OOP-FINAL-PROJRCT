
package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.service.LogService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminViewLogsScreen extends JFrame {

    private LogService logService = new LogService();
    private DefaultTableModel model;
    private JTable table;

    public AdminViewLogsScreen() {
        setTitle("View System Logs");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = gradientPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(panel);

        JLabel title = new JLabel("Activity Logs", SwingConstants.CENTER);
        title.setFont(new Font("Tahoma", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        panel.add(title, BorderLayout.NORTH);

        String[] cols = {"ID", "Timestamp", "User", "Action", "Details"};
        model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // grid is not editable
            }
        };

        table = new JTable(model);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        bottom.setOpaque(false);
        JButton btnRefresh = new JButton("Refresh");
        styleButton(btnRefresh);
        bottom.add(btnRefresh);
        panel.add(bottom, BorderLayout.SOUTH);

        loadLogs();

        btnRefresh.addActionListener(e -> loadLogs());
    }

    private void loadLogs() {
        model.setRowCount(0);
        List<LogEntry> logs = logService.getAllLogs();
        for (LogEntry log : logs) {
            model.addRow(new Object[]{
                    log.getId(),
                    log.getTimestamp(),
                    log.getUser(),
                    log.getAction(),
                    log.getDetails()
            });
        }
    }

    private JPanel gradientPanel() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
    }

    private void styleButton(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(231, 76, 60));
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(231, 76, 60)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(Color.WHITE);
                btn.setForeground(new Color(231, 76, 60));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(new Color(231, 76, 60));
                btn.setForeground(Color.WHITE);
            }
        });
    }
}
