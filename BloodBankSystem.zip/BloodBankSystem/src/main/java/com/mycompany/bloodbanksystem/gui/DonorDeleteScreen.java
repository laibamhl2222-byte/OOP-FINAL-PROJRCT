package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.service.DonorService;

import javax.swing.*;
import java.awt.*;

public class DonorDeleteScreen extends JFrame {
    private Donor donor;
    private JFrame parentMenu;
    
    private DonorService donorService = new DonorService();

    public DonorDeleteScreen(Donor donor, JFrame parentMenu) {
        this.donor = donor;
        this.parentMenu = parentMenu;
        
        setTitle("Delete Donor Profile");
        setSize(450, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        add(panel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblConfirm = new JLabel("Are you sure you want to delete this profile?");
        lblConfirm.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(lblConfirm, gbc);

        JButton btnDelete = new JButton("Delete");
        styleButton(btnDelete);
        gbc.gridy = 1;
        panel.add(btnDelete, gbc);

        btnDelete.addActionListener(e -> {
            donorService.deleteDonor(donor.getId());
            JOptionPane.showMessageDialog(this, "Profile deleted successfully!");
            parentMenu.dispose();          // close the donor menu
            dispose();                     // close delete screen
            new DonorLoginScreen().setVisible(true);  // Redirect to login
        });
    }

    private void styleButton(JButton btn) {
    btn.setFont(new Font("Tahoma", Font.BOLD, 16));
    btn.setBackground(Color.WHITE);                  // white text for contrast
    btn.setForeground(new Color(231, 76, 60));       // red background
    btn.setOpaque(true);
    btn.setFocusPainted(false);
    btn.setBorder(BorderFactory.createLineBorder(new Color(231, 76, 60))); // border same as background
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

    // Optional hover effect
    btn.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            btn.setForeground(new Color(200, 50, 50)); // darker red
        }
        public void mouseExited(java.awt.event.MouseEvent evt) {
            btn.setForeground(new Color(231, 76, 60));
        }
    });
}
}