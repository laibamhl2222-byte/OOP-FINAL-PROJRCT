package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.InventoryItem;
import com.mycompany.bloodbanksystem.service.InventoryService;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.UUID;

public class InventoryEditDialog extends JDialog {

    private JComboBox<String> cmbBloodGroup;
    private JSpinner spnUnits;
    private JTextField txtNotes;
    private boolean saved = false;
    private InventoryItem item;
    private InventoryService service = new InventoryService();
    private String adminUsername;

    private final String[] BLOOD_GROUPS = {"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"};

    public InventoryEditDialog(JFrame parent, InventoryItem item, String adminUsername) {
        super(parent, true);
        this.item = item;
        this.adminUsername = adminUsername;

        setTitle(item == null ? "Add Inventory" : "Edit Inventory");
        setSize(450, 250);
        setLocationRelativeTo(parent);
        setResizable(false);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(255, 245, 245));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10,10,10,10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Blood Group
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Blood Group:"), gbc);
        gbc.gridx = 1;
        cmbBloodGroup = new JComboBox<>(BLOOD_GROUPS);
        cmbBloodGroup.setFont(new Font("Tahoma", Font.PLAIN, 14));
        if (item != null) cmbBloodGroup.setSelectedItem(item.getBloodGroup());
        panel.add(cmbBloodGroup, gbc);

        // Units
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Units:"), gbc);
        gbc.gridx = 1;
        spnUnits = new JSpinner(new SpinnerNumberModel(item != null ? item.getUnits() : 0, 0, 1000, 1));
        spnUnits.setFont(new Font("Tahoma", Font.PLAIN, 14));
        panel.add(spnUnits, gbc);

        // Notes
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Notes:"), gbc);
        gbc.gridx = 1;
        txtNotes = new JTextField(item != null ? item.getNotes() : "");
        txtNotes.setFont(new Font("Tahoma", Font.PLAIN, 14));
        panel.add(txtNotes, gbc);

        // Buttons
        JPanel buttons = new JPanel();
        buttons.setBackground(new Color(255, 245, 245));
        JButton btnSave = new JButton("Save");
        JButton btnCancel = new JButton("Cancel");
        styleButton(btnSave); styleButton(btnCancel);
        buttons.add(btnSave);
        buttons.add(btnCancel);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(buttons, gbc);

        add(panel);

        // Actions
        btnSave.addActionListener(e -> save());
        btnCancel.addActionListener(e -> dispose());
    }

    private void save() {
        String bg = (String) cmbBloodGroup.getSelectedItem();
        int units = (Integer) spnUnits.getValue();
        String notes = txtNotes.getText().trim();

        if (bg.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a blood group!");
            return;
        }

        if (item == null) { // ADD ITEM
            InventoryItem existing = service.getByBloodGroup(bg);
            if (existing != null) {
                // Blood group exists: add units
                existing.setUnits(existing.getUnits() + units);
                if (!notes.isEmpty()) existing.setNotes(notes);
                service.updateItem(existing, adminUsername); // logging
            } else {
                InventoryItem newItem = new InventoryItem(
                        UUID.randomUUID().toString(), bg, units, LocalDate.now().toString(), notes);
                service.addItem(newItem, adminUsername); // logging
            }
        } else { // EDIT ITEM
            item.setBloodGroup(bg);
            item.setUnits(units);
            if (!notes.isEmpty()) item.setNotes(notes);
            service.updateItem(item, adminUsername); // logging
        }

        saved = true;
        dispose();
    }

    public boolean isSaved() { return saved; }

    private void styleButton(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(231,76,60));
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(231,76,60)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Color fg = btn.getForeground();
                btn.setForeground(btn.getBackground());
                btn.setBackground(fg);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setForeground(Color.WHITE);
                btn.setBackground(new Color(231,76,60));
            }
        });
    }
}
