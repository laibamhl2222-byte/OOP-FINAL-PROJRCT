package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.service.RecipientService;

import javax.swing.*;
import java.awt.*;

public class RecipientMenu extends JFrame {

    private Recipient recipient;
    private RecipientService recipientService = new RecipientService();

    public RecipientMenu(Recipient recipient) {
        this.recipient = recipient;

        setTitle("Recipient Menu");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Gradient panel
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));
        add(panel);

        // Title
        JLabel title = new JLabel("Welcome " + recipient.getName());
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Tahoma", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        panel.add(title);

        panel.add(Box.createRigidArea(new Dimension(0, 50)));

        // Buttons
        JButton btnView = new JButton("View Request");
        JButton btnUpdate = new JButton("Update Request");
        JButton btnDelete = new JButton("Delete Request");
        JButton btnFindDonor = new JButton("Find Compatible Donors");
        JButton btnLogout = new JButton("Logout");

        styleButton(btnView);
        styleButton(btnUpdate);
        styleButton(btnDelete);
        styleButton(btnFindDonor);
        styleButton(btnLogout);

        panel.add(btnView);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnUpdate);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnDelete);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnFindDonor);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnLogout);

        // View Request → opens RecipientViewScreen
btnView.addActionListener(e -> new RecipientViewScreen(recipient).setVisible(true));

// Update Request → opens RecipientUpdateScreen
btnUpdate.addActionListener(e -> new RecipientUpdateScreen(recipient).setVisible(true));

// Delete Request → confirmation dialog, then back to WelcomeScreen
btnDelete.addActionListener(e -> {
    int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to delete this request?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION
    );
    if (confirm == JOptionPane.YES_OPTION) {
        recipientService.deleteRecipient(recipient.getId());
        JOptionPane.showMessageDialog(this, "Request deleted successfully!");
        dispose(); // close menu
        new WelcomeScreen().setVisible(true); // return to login/welcome
    }
});

// Find Compatible Donors → opens CompatibleDonorSearchScreen
btnFindDonor.addActionListener(e -> new CompatibleDonorSearchScreen(recipient).setVisible(true));

// Logout → return to WelcomeScreen
btnLogout.addActionListener(e -> {
    dispose();
    new WelcomeScreen().setVisible(true);
});
    }

    private void styleButton(JButton btn) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(new Color(255, 255, 255)); // white
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(300, 55));
        btn.setMaximumSize(new Dimension(300, 55));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(200, 50, 50)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(255, 255, 255)); }
        });
    }
}