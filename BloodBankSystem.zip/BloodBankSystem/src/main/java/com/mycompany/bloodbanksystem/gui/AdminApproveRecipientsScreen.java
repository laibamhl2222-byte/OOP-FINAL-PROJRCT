package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.service.RecipientService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminApproveRecipientsScreen extends JFrame {

    private RecipientService recipientService = new RecipientService();
    private DefaultTableModel model;
    private JTable table;

    private String adminUsername; // received from dashboard login

    public AdminApproveRecipientsScreen(String adminUsername) {
        this.adminUsername = adminUsername;

        setTitle("Approve Recipient Requests");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = gradientPanel();
        panel.setLayout(new BorderLayout(10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        add(panel);

        JLabel title = new JLabel("Pending Recipient Requests", SwingConstants.CENTER);
        title.setFont(new Font("Tahoma", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        panel.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","Name","Age","Gender","Contact","Username","RequiredGroup","Urgency"};
        model = new DefaultTableModel(cols,0);
        table = new JTable(model);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        bottom.setOpaque(false);
        JButton btnRefresh = new JButton("Refresh");
        JButton btnApprove = new JButton("Approve Selected");
        JButton btnReject = new JButton("Reject Selected");
        style(btnRefresh); style(btnApprove); style(btnReject);

        bottom.add(btnRefresh);
        bottom.add(btnApprove);
        bottom.add(btnReject);
        panel.add(bottom, BorderLayout.SOUTH);

        loadPending();

        btnRefresh.addActionListener(e -> loadPending());

        btnApprove.addActionListener(e -> approveSelected());
        btnReject.addActionListener(e -> rejectSelected());
    }

    private void approveSelected() {
        int r = table.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Select a row");
            return;
        }

        String id = (String) model.getValueAt(r, 0);
        Recipient rec = recipientService.getRecipientFromPending(id);

        if (rec == null) {
            JOptionPane.showMessageDialog(this, "Could not find entry");
            return;
        }

        recipientService.approveRecipient(rec, adminUsername);
        JOptionPane.showMessageDialog(this, "Recipient approved successfully");
        loadPending();
    }

    private void rejectSelected() {
        int r = table.getSelectedRow();
        if (r == -1) {
            JOptionPane.showMessageDialog(this, "Select a row");
            return;
        }

        String id = (String) model.getValueAt(r, 0);

        recipientService.rejectPendingRecipient(id, adminUsername);

        JOptionPane.showMessageDialog(this, "Recipient rejected");
        loadPending();
    }

    private void loadPending() {
        model.setRowCount(0);

        List<Recipient> pending = recipientService.getPendingRecipients();
        for (Recipient r : pending) {
            model.addRow(new Object[]{
                r.getId(), r.getName(), r.getAge(), r.getGender(),
                r.getContact(), r.getUsername(), r.getRequiredBloodGroup(),
                r.getUrgency()
            });
        }
    }

    private JPanel gradientPanel() {
        return new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setPaint(new GradientPaint(0, 0,
                        new Color(220,53,69), 0, getHeight(),
                        new Color(255,102,102)));
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
    }

    private void style(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(231,76,60));
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createLineBorder(new Color(231,76,60)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
}
