package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;

import javax.swing.*;
import java.awt.*;

public class DonorMenu extends JFrame {

    private Donor donor;

    public DonorMenu(Donor donor) {
        this.donor = donor;

        setTitle("Donor Menu");
        setSize(600, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));
        add(panel);

        JLabel title = new JLabel("Welcome " + donor.getName());
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Tahoma", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        panel.add(title);

        panel.add(Box.createRigidArea(new Dimension(0, 50)));

        JButton btnView = new JButton("View Profile");
        JButton btnUpdate = new JButton("Update Profile");
        JButton btnDelete = new JButton("Delete Profile");
        JButton btnEligibility = new JButton("Set Eligibility / Donation History");
        JButton btnLogout = new JButton("Logout");

        styleButton(btnView);
        styleButton(btnUpdate);
        styleButton(btnDelete);
        styleButton(btnEligibility);
        styleButton(btnLogout);

        panel.add(btnView);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnUpdate);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnDelete);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnEligibility);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnLogout);

        // Actions
        btnView.addActionListener(e -> new DonorViewScreen(donor).setVisible(true));
        btnUpdate.addActionListener(e -> new DonorUpdateScreen(donor).setVisible(true));
        btnDelete.addActionListener(e -> new DonorDeleteScreen(donor, this).setVisible(true));
        btnEligibility.addActionListener(e -> new DonorEligibilityScreen(donor).setVisible(true));
        btnLogout.addActionListener(e -> {
            dispose();
            new WelcomeScreen().setVisible(true);
        });
    }

    private void styleButton(JButton btn) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(new Color(255, 255, 255)); // white
        btn.setPreferredSize(new Dimension(350, 55));
        btn.setMaximumSize(new Dimension(350, 55));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(200, 50, 50)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(255, 255, 255)); }
        });
    }
}