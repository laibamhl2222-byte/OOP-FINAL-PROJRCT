package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.model.InventoryItem;
import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.service.DonorService;
import com.mycompany.bloodbanksystem.service.InventoryService;
import com.mycompany.bloodbanksystem.service.LogService;
import com.mycompany.bloodbanksystem.service.RecipientService;
import com.mycompany.bloodbanksystem.util.FileUtil;

import javax.swing.*;

import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class AdminReportGenerationScreen extends JFrame {

    private DonorService donorService = new DonorService();
    private RecipientService recipientService = new RecipientService();
    private InventoryService inventoryService = new InventoryService();
    private LogService logService = new LogService();

    private DefaultTableModel donorModel, recipientModel, inventoryModel, logModel;

    public AdminReportGenerationScreen() {
        setTitle("Admin Report Generation");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(255, 230, 230));

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Donors", createDonorReportPanel());
        tabs.addTab("Recipients", createRecipientReportPanel());
        tabs.addTab("Inventory", createInventoryReportPanel());
        tabs.addTab("Logs", createLogsReportPanel());

        add(tabs);
    }

    // -------------------- DONORS REPORT --------------------
    private JPanel createDonorReportPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        donorModel = new DefaultTableModel(new String[]{"ID","Name","Blood Group","Contact"},0){
            @Override public boolean isCellEditable(int row, int column){ return false; }
        };
        JTable table = new JTable(donorModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        // Filter Panel
        JPanel filterPanel = new JPanel();
        filterPanel.setBackground(new Color(255,230,230));
        filterPanel.add(new JLabel("Blood Group:"));
        String[] bloodGroups = {"All","O+","O-","A+","A-","B+","B-","AB+","AB-"};
        JComboBox<String> cmbFilter = new JComboBox<>(bloodGroups);
        filterPanel.add(cmbFilter);

        JButton btnFilter = new JButton("Apply Filter");
        styleButton(btnFilter);
        btnFilter.addActionListener(e -> loadDonors(cmbFilter.getSelectedItem().toString()));
        filterPanel.add(btnFilter);

        panel.add(filterPanel, BorderLayout.NORTH);

        JButton btnExport = new JButton("Export to CSV");
        styleButton(btnExport);
        btnExport.addActionListener(e -> exportTableToCSV(table, "donors_report.csv"));

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnExport);
        panel.add(bottom, BorderLayout.SOUTH);

        loadDonors("All");
        return panel;
    }

    private void loadDonors(String bloodGroup) {
        donorModel.setRowCount(0);
        List<Donor> list = donorService.getAllDonors();
        if(!bloodGroup.equals("All")) {
            list = list.stream().filter(d -> bloodGroup.equals(d.getBloodGroup())).collect(Collectors.toList());
        }
        for(Donor d : list){
            donorModel.addRow(new Object[]{d.getId(), d.getName(), d.getBloodGroup(), d.getContact()});
        }
    }

    // -------------------- RECIPIENTS REPORT --------------------
    private JPanel createRecipientReportPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        recipientModel = new DefaultTableModel(new String[]{"ID","Name","Blood Group","Contact"},0){
            @Override public boolean isCellEditable(int row,int col){ return false; }
        };
        JTable table = new JTable(recipientModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel filterPanel = new JPanel();
        filterPanel.setBackground(new Color(255,230,230));
        filterPanel.add(new JLabel("Blood Group:"));
        String[] bloodGroups = {"All","O+","O-","A+","A-","B+","B-","AB+","AB-"};
        JComboBox<String> cmbFilter = new JComboBox<>(bloodGroups);
        filterPanel.add(cmbFilter);

        JButton btnFilter = new JButton("Apply Filter");
        styleButton(btnFilter);
        btnFilter.addActionListener(e -> loadRecipients(cmbFilter.getSelectedItem().toString()));
        filterPanel.add(btnFilter);

        panel.add(filterPanel, BorderLayout.NORTH);

        JButton btnExport = new JButton("Export to CSV");
        styleButton(btnExport);
        btnExport.addActionListener(e -> exportTableToCSV(table, "recipients_report.csv"));

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnExport);
        panel.add(bottom, BorderLayout.SOUTH);

        loadRecipients("All");
        return panel;
    }

    private void loadRecipients(String bloodGroup) {
        recipientModel.setRowCount(0);
        List<Recipient> list = recipientService.getAllRecipients();
        if(!bloodGroup.equals("All")) {
            list = list.stream().filter(r -> bloodGroup.equals(r.getRequiredBloodGroup())).collect(Collectors.toList());
        }
        for(Recipient r : list){
            recipientModel.addRow(new Object[]{r.getId(), r.getName(), r.getRequiredBloodGroup(), r.getContact()});
        }
    }

    // -------------------- INVENTORY REPORT --------------------
    private JPanel createInventoryReportPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        inventoryModel = new DefaultTableModel(new String[]{"ID","Blood Group","Units","Notes"},0){
            @Override public boolean isCellEditable(int row,int col){ return false; }
        };
        JTable table = new JTable(inventoryModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel filterPanel = new JPanel();
        filterPanel.setBackground(new Color(255,230,230));
        filterPanel.add(new JLabel("Blood Group:"));
        String[] bloodGroups = {"All","O+","O-","A+","A-","B+","B-","AB+","AB-"};
        JComboBox<String> cmbFilter = new JComboBox<>(bloodGroups);
        filterPanel.add(cmbFilter);

        filterPanel.add(new JLabel("Min Units:"));
        JTextField txtUnits = new JTextField(5);
        filterPanel.add(txtUnits);

        JButton btnFilter = new JButton("Apply Filter");
        styleButton(btnFilter);
        btnFilter.addActionListener(e -> {
            int minUnits = 0;
            try { minUnits = Integer.parseInt(txtUnits.getText().trim()); } catch(Exception ignored) {}
            loadInventory(cmbFilter.getSelectedItem().toString(), minUnits);
        });
        filterPanel.add(btnFilter);
        panel.add(filterPanel, BorderLayout.NORTH);

        JButton btnExport = new JButton("Export to CSV");
        styleButton(btnExport);
        btnExport.addActionListener(e -> exportTableToCSV(table, "inventory_report.csv"));

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnExport);
        panel.add(bottom, BorderLayout.SOUTH);

        loadInventory("All",0);
        return panel;
    }

    private void loadInventory(String bloodGroup, int minUnits) {
        inventoryModel.setRowCount(0);
        List<InventoryItem> list = inventoryService.getAll();
        if(!bloodGroup.equals("All")) {
            list = list.stream().filter(i -> bloodGroup.equals(i.getBloodGroup())).collect(Collectors.toList());
        }
        list = list.stream().filter(i -> i.getUnits() >= minUnits).collect(Collectors.toList());
        for(InventoryItem i : list){
            inventoryModel.addRow(new Object[]{i.getId(), i.getBloodGroup(), i.getUnits(), i.getNotes()});
        }
    }

    // -------------------- LOGS REPORT --------------------
    private JPanel createLogsReportPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        logModel = new DefaultTableModel(new String[]{"Timestamp","Admin","Action","Details"},0){
            @Override public boolean isCellEditable(int row,int col){ return false; }
        };
        JTable table = new JTable(logModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel filterPanel = new JPanel();
        filterPanel.setBackground(new Color(255,230,230));
        filterPanel.add(new JLabel("Admin:"));
        JTextField txtAdmin = new JTextField(10);
        filterPanel.add(txtAdmin);

        JButton btnFilter = new JButton("Apply Filter");
        styleButton(btnFilter);
        btnFilter.addActionListener(e -> loadLogs(txtAdmin.getText().trim()));
        filterPanel.add(btnFilter);

        panel.add(filterPanel, BorderLayout.NORTH);

        JButton btnExport = new JButton("Export to CSV");
        styleButton(btnExport);
        btnExport.addActionListener(e -> exportTableToCSV(table, "logs_report.csv"));

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnExport);
        panel.add(bottom, BorderLayout.SOUTH);

        loadLogs("");
        return panel;
    }

    private void loadLogs(String adminFilter) {
        logModel.setRowCount(0);
        List<LogEntry> logs = logService.getAllLogs();
        if(!adminFilter.isEmpty()) {
            logs = logs.stream().filter(l -> l.getUser() != null && l.getUser().contains(adminFilter)).collect(Collectors.toList());
        }
        for(LogEntry l : logs){
            logModel.addRow(new Object[]{
                    l.getTimestamp() != null ? l.getTimestamp() : "",
                    l.getUser() != null ? l.getUser() : "",
                    l.getAction() != null ? l.getAction() : "",
                    l.getDetails() != null ? l.getDetails() : ""
            });
        }
    }

    // -------------------- CSV EXPORT --------------------
    private void exportTableToCSV(JTable table, String filename) {
        try {
            File file = new File(filename);
            StringBuilder sb = new StringBuilder();

            for(int i=0; i<table.getColumnCount(); i++){
                sb.append(table.getColumnName(i));
                if(i != table.getColumnCount()-1) sb.append(",");
            }
            sb.append("\n");

            for(int r=0; r<table.getRowCount(); r++){
                for(int c=0; c<table.getColumnCount(); c++){
                    sb.append(table.getValueAt(r,c));
                    if(c != table.getColumnCount()-1) sb.append(",");
                }
                sb.append("\n");
            }

            FileUtil.writeStringToFile(file.getAbsolutePath(), sb.toString());
            JOptionPane.showMessageDialog(this,"Exported to "+file.getAbsolutePath());
        } catch (Exception ex){
            JOptionPane.showMessageDialog(this,"Error exporting: "+ex.getMessage());
        }
    }

    // -------------------- BUTTON STYLING --------------------
    private void styleButton(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(231,76,60));
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(231,76,60)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Color fg = btn.getForeground();
                btn.setForeground(btn.getBackground());
                btn.setBackground(fg);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setForeground(Color.WHITE);
                btn.setBackground(new Color(231,76,60));
            }
        });
    }
}
