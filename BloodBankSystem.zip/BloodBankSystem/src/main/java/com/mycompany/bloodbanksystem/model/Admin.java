package com.mycompany.bloodbanksystem.model;

public class Admin extends User {

    public Admin() {}

    public Admin(String id, String name, int age, String gender,
                 String contact, String username, String password) {

        super(id, name, age, gender, contact, username, password);
    }
}