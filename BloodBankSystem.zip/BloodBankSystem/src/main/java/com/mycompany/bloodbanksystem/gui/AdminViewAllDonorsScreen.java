package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.service.DonorService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminViewAllDonorsScreen extends JFrame {

    private DonorService donorService = new DonorService();

    public AdminViewAllDonorsScreen() {
        setTitle("View All Donors");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Gradient panel
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(panel);

        JLabel lblTitle = new JLabel("All Donors");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(lblTitle, BorderLayout.NORTH);

        // Table
        String[] columns = {"ID", "Name", "Age", "Gender", "Contact", "Username",
                "Blood Group", "Medical Status", "Last Donation", "Eligible"};
        DefaultTableModel model = new DefaultTableModel(columns, 0){
    @Override
    public boolean isCellEditable(int row, int column) {
        return false; // all cells read-only
    }
};

        List<Donor> donors = donorService.getAllDonors();
        for (Donor d : donors) {
            model.addRow(new Object[]{
                    d.getId(), d.getName(), d.getAge(), d.getGender(), d.getContact(),
                    d.getUsername(), d.getBloodGroup(), d.getMedicalStatus(),
                    d.getLastDonationDate(), d.isEligible()
            });
        }

        JTable table = new JTable(model);
        table.setFont(new Font("Tahoma", Font.PLAIN, 14));
        table.setRowHeight(25);
        JScrollPane scroll = new JScrollPane(table);
        panel.add(scroll, BorderLayout.CENTER);

        // Close button
        JButton btnClose = new JButton("Close");
        styleButton(btnClose);
        btnClose.addActionListener(e -> dispose());
        JPanel bottomPanel = new JPanel();
        bottomPanel.setOpaque(false);
        bottomPanel.add(btnClose);
        panel.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void styleButton(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 16));
        btn.setForeground(Color.RED);
        btn.setBackground(Color.WHITE);
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(Color.RED));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setForeground(Color.WHITE);
                btn.setBackground(Color.RED);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setForeground(Color.RED);
                btn.setBackground(Color.WHITE);
            }
        });
    }
}