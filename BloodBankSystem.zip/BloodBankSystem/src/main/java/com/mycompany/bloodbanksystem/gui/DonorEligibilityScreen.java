
package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.service.DonorService;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class DonorEligibilityScreen extends JFrame {

    private DonorService donorService = new DonorService();

    public DonorEligibilityScreen(Donor donor) {
        setTitle("Set Eligibility & Donation History");
        setSize(500, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        add(panel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Eligibility checkbox
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        JCheckBox eligibleBox = new JCheckBox("Eligible to Donate", donor.isEligible());
        eligibleBox.setForeground(Color.RED);
        panel.add(eligibleBox, gbc);

        // Last donation date
        gbc.gridy = 1; gbc.gridwidth = 1;
        JLabel lblLast = new JLabel("Last Donation Date (yyyy-mm-dd):");
        lblLast.setForeground(Color.WHITE);
        panel.add(lblLast, gbc);

        gbc.gridx = 1;
        JTextField lastDonation = new JTextField(donor.getLastDonationDate(), 15);
        panel.add(lastDonation, gbc);

        // Update button
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton btnUpdate = new JButton("Update");
        styleButton(btnUpdate);
        panel.add(btnUpdate, gbc);

        btnUpdate.addActionListener(e -> {
    String lastDonationDate = lastDonation.getText().trim();

    // Validate date format
    try {
        LocalDate.parse(lastDonationDate); // throws exception if invalid
    } catch (DateTimeParseException ex) {
        JOptionPane.showMessageDialog(this,
                "Invalid date format. Use yyyy-MM-dd",
                "Error",
                JOptionPane.ERROR_MESSAGE);
        return; // stop update
    }

    // Update donor info
    donor.setEligible(eligibleBox.isSelected());
    donor.setLastDonationDate(lastDonationDate);
    donorService.updateDonor(donor);

    JOptionPane.showMessageDialog(this, "Eligibility & donation updated!");
    dispose(); // optionally close the window
});
    }

    private void styleButton(JButton btn) {
    btn.setFont(new Font("Tahoma", Font.BOLD, 16));
    btn.setBackground(Color.RED);                  
    btn.setForeground(new Color(255, 255, 255));       // White
    btn.setOpaque(true);
    btn.setFocusPainted(false);
    btn.setBorder(BorderFactory.createLineBorder(new Color(231, 76, 60))); // border same as background
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

    // Optional hover effect
    btn.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            btn.setForeground(new Color(200, 50, 50)); // darker red
        }
        public void mouseExited(java.awt.event.MouseEvent evt) {
            btn.setForeground(new Color(255, 255, 255));
        }
    });
}
}
