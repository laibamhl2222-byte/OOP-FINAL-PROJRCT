package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.service.DonorService;

import javax.swing.*;
import java.awt.*;

public class DonorUpdateScreen extends JFrame {

    private JTextField txtContact, txtMedicalStatus;
    private DonorService donorService = new DonorService();

    public DonorUpdateScreen(Donor donor) {
        setTitle("Update Donor Profile");
        setSize(500, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        add(panel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Contact
        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lblContact = new JLabel("Contact:");
        lblContact.setForeground(Color.WHITE);
        panel.add(lblContact, gbc);

        gbc.gridx = 1;
        txtContact = new JTextField(donor.getContact(), 20);
        panel.add(txtContact, gbc);

        // Medical Status
        gbc.gridx = 0; gbc.gridy = 1;
        JLabel lblMedical = new JLabel("Medical Status:");
        lblMedical.setForeground(Color.WHITE);
        panel.add(lblMedical, gbc);

        gbc.gridx = 1;
        txtMedicalStatus = new JTextField(donor.getMedicalStatus(), 20);
        panel.add(txtMedicalStatus, gbc);

        // Update Button
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JButton btnUpdate = new JButton("Update");
        styleButton(btnUpdate);
        panel.add(btnUpdate, gbc);

        btnUpdate.addActionListener(e -> {
            donor.setContact(txtContact.getText());
            donor.setMedicalStatus(txtMedicalStatus.getText());
            donorService.updateDonor(donor);
            JOptionPane.showMessageDialog(this, "Profile updated successfully!");
            dispose();
        });
    }

private void styleButton(JButton btn) {
    btn.setFont(new Font("Tahoma", Font.BOLD, 16));
    btn.setBackground(Color.RED);              
    btn.setForeground(new Color(255, 255, 255));       // White background
    btn.setOpaque(true);
    btn.setFocusPainted(false);
    btn.setBorder(BorderFactory.createLineBorder(new Color(231, 76, 60))); // border same as background
    btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

    // Optional hover effect
    btn.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseEntered(java.awt.event.MouseEvent evt) {
            btn.setForeground(new Color(200, 50, 50)); // darker red
        }
        public void mouseExited(java.awt.event.MouseEvent evt) {
            btn.setForeground(new Color(255, 255, 255));
        }
    });
}
}
