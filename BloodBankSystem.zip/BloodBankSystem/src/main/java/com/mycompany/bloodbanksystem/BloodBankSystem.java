package com.mycompany.bloodbanksystem;

import com.mycompany.bloodbanksystem.gui.WelcomeScreen;
import com.mycompany.bloodbanksystem.model.Admin;
import com.mycompany.bloodbanksystem.service.AdminService;

import javax.swing.SwingUtilities;

public class BloodBankSystem {

    public static void main(String[] args) {
        // Ensure default admin exists
        AdminService adminService = new AdminService();
        if (adminService.getAllAdmins().isEmpty()) {
            Admin defaultAdmin = new Admin(
                    "A001",
                    "Super Admin",
                    35,
                    "Female",
                    "03001234567",
                    "Aleena",
                    "admin123"
            );
            adminService.addAdmin(defaultAdmin);
            System.out.println("Default admin created!");
        }

        // Launch the GUI safely in the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            WelcomeScreen welcomeScreen = new WelcomeScreen();
            welcomeScreen.setVisible(true);
        });
    }
}
