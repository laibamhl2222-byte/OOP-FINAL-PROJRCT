package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Recipient;

import javax.swing.*;
import java.awt.*;

public class RecipientViewScreen extends JFrame {

    private Recipient recipient;

    public RecipientViewScreen(Recipient recipient) {
        this.recipient = recipient;

        setTitle("View Recipient Request");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Gradient panel
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 80, 40, 80));
        add(panel);

        JLabel title = new JLabel("Recipient Request Details");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Tahoma", Font.BOLD, 24));
        title.setForeground(Color.WHITE);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 15)));

        panel.add(createFieldRow("Name", recipient.getName()));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Required Blood Group", recipient.getRequiredBloodGroup()));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Urgency Level", recipient.getUrgency()));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));


        JButton btnClose = new JButton("Close");
        styleButton(btnClose);
        btnClose.addActionListener(e -> dispose());
        panel.add(btnClose);
    }

    private JPanel createFieldRow(String labelText, String valueText) {
    JPanel row = new JPanel(new GridLayout(1, 2, 10, 0)); // 1 row, 2 columns, 10px horizontal gap
    row.setOpaque(false);

    JLabel label = new JLabel(labelText + ": ");
    label.setFont(new Font("Tahoma", Font.PLAIN, 16));
    label.setForeground(Color.WHITE);

    JLabel field = new JLabel(valueText);
    field.setFont(new Font("Tahoma", Font.BOLD, 16)); // bold to distinguish value
    field.setForeground(Color.WHITE);

    row.add(label);
    row.add(field);
    return row;
    }

    private void styleButton(JButton btn) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(new Color(255, 255, 255));
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(250, 55));
        btn.setMaximumSize(new Dimension(250, 55));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(200, 50, 50)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(255, 255, 255)); }
        });
    }
}
