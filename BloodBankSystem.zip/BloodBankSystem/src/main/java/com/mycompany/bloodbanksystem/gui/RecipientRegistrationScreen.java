package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.service.RecipientService;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.util.UUID;

public class RecipientRegistrationScreen extends JFrame {

    private JTextField txtName, txtAge, txtContact, txtUrgency, txtUsername;
    private JPasswordField txtPassword;
    private JComboBox<String> cbGender, cbBloodGroup;
    private RecipientService recipientService = new RecipientService();

    public RecipientRegistrationScreen() {
        setTitle("Recipient Registration");
        setSize(650, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Gradient panel
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        add(panel);

        // Title
        JLabel lblTitle = new JLabel("Recipient Registration");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(lblTitle);
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Fields
        txtName = new JTextField();
        txtAge = new JTextField();
        cbGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        txtContact = new JTextField();
        cbBloodGroup = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        txtUrgency = new JTextField();
        txtUsername = new JTextField();
        txtPassword = new JPasswordField();

        panel.add(createFieldRow("Name", txtName));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Age", txtAge));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Gender", cbGender));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Contact", txtContact));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Required Blood Group", cbBloodGroup));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Urgency Level", txtUrgency));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Username", txtUsername));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Password", txtPassword));
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        // Register Button
        JButton btnRegister = new JButton("Register");
        styleButton(btnRegister, new Color(245, 245, 220)); // beige
        panel.add(btnRegister);

        btnRegister.addActionListener(e -> registerRecipient());
    }

    private JPanel createFieldRow(String labelText, JComponent field) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        row.setOpaque(false);

        JLabel label = new JLabel(labelText + ": ");
        label.setFont(new Font("Tahoma", Font.PLAIN, 16));
        label.setForeground(Color.WHITE);
        label.setPreferredSize(new Dimension(220, 25));
        label.setMaximumSize(new Dimension(220, 25));

        field.setPreferredSize(new Dimension(250, 35));
        field.setMaximumSize(new Dimension(250, 35));
        if (field instanceof JTextField)
            ((JTextField) field).setFont(new Font("Tahoma", Font.PLAIN, 16));
        else if (field instanceof JComboBox)
            ((JComboBox<?>) field).setFont(new Font("Tahoma", Font.PLAIN, 16));

        row.add(label);
        row.add(Box.createRigidArea(new Dimension(20, 0)));
        row.add(field);

        return row;
    }

    private void styleButton(JButton btn, Color color) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(color);
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(250, 60));
        btn.setMaximumSize(new Dimension(250, 60));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(color.darker()); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(color); }
        });
    }

    private void registerRecipient() {
        String name = txtName.getText();
        String ageStr = txtAge.getText();
        String contact = txtContact.getText();
        String bloodGroup = cbBloodGroup.getSelectedItem().toString();
        String urgency = txtUrgency.getText();
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());
        String gender = cbGender.getSelectedItem().toString();

        // Validate fields
        if (name.isEmpty() || ageStr.isEmpty() || contact.isEmpty() || bloodGroup.isEmpty() ||
                urgency.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate age
        int age;
        try {
            age = Integer.parseInt(ageStr);
            if (age < 0 || age > 120) {
                JOptionPane.showMessageDialog(this, "Invalid age", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid age", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String id = UUID.randomUUID().toString();
        Recipient recipient = new Recipient(id, name, age, gender, contact, username, password, bloodGroup, urgency);
        recipientService.addPendingRecipient(recipient);

        JOptionPane.showMessageDialog(this, "Registration successful! Await admin approval.");
        dispose();
        new RecipientLoginScreen().setVisible(true);
    }
}
