package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.service.RecipientService;

import javax.swing.*;
import java.awt.*;

public class RecipientUpdateScreen extends JFrame {

    private Recipient recipient;
    private RecipientService recipientService = new RecipientService();

    private JTextField txtContact, txtUrgency;
    private JComboBox<String> cbBloodGroup;

    public RecipientUpdateScreen(Recipient recipient) {
        this.recipient = recipient;

        setTitle("Update Recipient Request");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        add(panel);

        JLabel title = new JLabel("Update Request");
        title.setFont(new Font("Tahoma", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        txtContact = new JTextField(recipient.getContact());
        cbBloodGroup = new JComboBox<>(new String[]{"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"});
        cbBloodGroup.setSelectedItem(recipient.getRequiredBloodGroup());
        txtUrgency = new JTextField(recipient.getUrgency());

        panel.add(createFieldRow("Contact", txtContact));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Required Blood Group", cbBloodGroup));
        panel.add(Box.createRigidArea(new Dimension(0, 15)));
        panel.add(createFieldRow("Urgency Level", txtUrgency));
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        JButton btnUpdate = new JButton("Update");
        styleButton(btnUpdate);
        panel.add(btnUpdate);

        btnUpdate.addActionListener(e -> {
            recipient.setContact(txtContact.getText());
            recipient.setRequiredBloodGroup(cbBloodGroup.getSelectedItem().toString());
            recipient.setUrgency(txtUrgency.getText());
            recipientService.updateRecipient(recipient);
            JOptionPane.showMessageDialog(this, "Request updated successfully!");
            dispose();
        });
    }

    private JPanel createFieldRow(String labelText, JComponent field) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        row.setOpaque(false);

        JLabel label = new JLabel(labelText + ": ");
        label.setFont(new Font("Tahoma", Font.PLAIN, 16));
        label.setForeground(Color.WHITE);
        label.setPreferredSize(new Dimension(220, 25));
        label.setMaximumSize(new Dimension(220, 25));

        field.setFont(new Font("Tahoma", Font.PLAIN, 16));
        if (field instanceof JTextField) {
            ((JTextField) field).setPreferredSize(new Dimension(250, 35));
            ((JTextField) field).setMaximumSize(new Dimension(250, 35));
        } else if (field instanceof JComboBox) {
            ((JComboBox<?>) field).setPreferredSize(new Dimension(250, 35));
            ((JComboBox<?>) field).setMaximumSize(new Dimension(250, 35));
        }

        row.add(label);
        row.add(Box.createRigidArea(new Dimension(20, 0)));
        row.add(field);
        return row;
    }

    private void styleButton(JButton btn) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(new Color(255, 255, 255)); // white
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(250, 55));
        btn.setMaximumSize(new Dimension(250, 55));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(200, 50, 50)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(255, 255, 255)); }
        });
    }
}
