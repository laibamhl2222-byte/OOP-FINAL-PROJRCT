package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.service.DonorService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CompatibleDonorSearchScreen extends JFrame {

    private Recipient recipient;
    private DonorService donorService = new DonorService();

    public CompatibleDonorSearchScreen(Recipient recipient) {
        this.recipient = recipient;

        setTitle("Compatible Donors");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        add(panel);

        JLabel lblTitle = new JLabel("Compatible Donors for " + recipient.getName(), SwingConstants.CENTER);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblTitle.setForeground(Color.WHITE);
        panel.add(lblTitle, BorderLayout.NORTH);

        // Table
        String[] columns = {"Name", "Age", "Gender", "Contact", "Blood Group", "Last Donation", "Eligible"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);
        table.setFont(new Font("Tahoma", Font.PLAIN, 16));
        table.setRowHeight(30);
        table.setEnabled(false);

        List<Donor> compatibleDonors = donorService.searchByBloodGroup(recipient.getRequiredBloodGroup());
        for (Donor d : compatibleDonors) {
            model.addRow(new Object[]{
                    d.getName(), d.getAge(), d.getGender(), d.getContact(),
                    d.getBloodGroup(), d.getLastDonationDate(), d.isEligible() ? "Yes" : "No"
            });
        }

        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Close button
        JButton btnClose = new JButton("Close");
        styleButton(btnClose, new Color(231, 76, 60));
        btnClose.addActionListener(e -> dispose());
        panel.add(btnClose, BorderLayout.SOUTH);
    }

    private void styleButton(JButton btn, Color color) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(color);
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(200, 50));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(color.darker()); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(color); }
        });
    }
}
