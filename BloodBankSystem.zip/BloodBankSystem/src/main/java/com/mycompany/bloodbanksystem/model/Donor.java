package com.mycompany.bloodbanksystem.model;

public class Donor extends User {

    private String bloodGroup;
    private String medicalStatus;
    private String lastDonationDate;
    private boolean eligible;

    public Donor() {}

    public Donor(String id, String name, int age, String gender, String contact,
                 String username, String password,
                 String bloodGroup, String medicalStatus,
                 String lastDonationDate, boolean eligible) {

        super(id, name, age, gender, contact, username, password);

        this.bloodGroup = bloodGroup;
        this.medicalStatus = medicalStatus;
        this.lastDonationDate = lastDonationDate;
        this.eligible = eligible;
    }

    // Getters & Setters
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getMedicalStatus() { return medicalStatus; }
    public void setMedicalStatus(String medicalStatus) { this.medicalStatus = medicalStatus; }

    public String getLastDonationDate() { return lastDonationDate; }
    public void setLastDonationDate(String lastDonationDate) { this.lastDonationDate = lastDonationDate; }

    public boolean isEligible() { return eligible; }
    public void setEligible(boolean eligible) { this.eligible = eligible; }
}