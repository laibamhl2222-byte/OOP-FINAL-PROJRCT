package com.mycompany.bloodbanksystem.service;

import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.util.FileUtil;

import java.util.ArrayList;
import java.util.List;

public class RecipientService {

    private final String FILE = "recipients.txt";                 // Approved recipients
    private final String PENDING_FILE = "pending_recipients.txt"; // Pending recipients

    // Convert Recipient object → CSV
    private String toCSV(Recipient r) {
        return r.getId() + "," + r.getName() + "," + r.getAge() + "," +
               r.getGender() + "," + r.getContact() + "," +
               r.getUsername() + "," + r.getPassword() + "," +
               r.getRequiredBloodGroup() + "," + r.getUrgency();
    }

    // Convert CSV → Recipient object
    public Recipient csvToRecipient(String line) {
        String[] a = line.split(",");
        return new Recipient(
            a[0], a[1], Integer.parseInt(a[2]), a[3], a[4],
            a[5], a[6], a[7], a[8]
        );
    }

    // Private helper
    private Recipient fromCSV(String line) {
        return csvToRecipient(line);
    }

    // ============================================================
    // APPROVED RECIPIENTS CRUD   (unchanged, safe to reuse)
    // ============================================================
    public void addRecipient(Recipient r) {
        List<String> list = FileUtil.readFileToList(FILE);
        list.add(toCSV(r));
        FileUtil.writeListToFile(FILE, list);
    }

    public List<Recipient> getAllRecipients() {
        List<Recipient> list = new ArrayList<>();
        for (String s : FileUtil.readFileToList(FILE)) {
            list.add(fromCSV(s));
        }
        return list;
    }

    public void updateRecipient(Recipient updated) {
        List<String> list = FileUtil.readFileToList(FILE);
        List<String> newList = new ArrayList<>();

        for (String line : list) {
            Recipient r = fromCSV(line);
            if (r.getId().equals(updated.getId())) {
                newList.add(toCSV(updated));
            } else {
                newList.add(line);
            }
        }
        FileUtil.writeListToFile(FILE, newList);
    }

    public void deleteRecipient(String id) {
        List<String> list = FileUtil.readFileToList(FILE);
        list.removeIf(s -> s.startsWith(id + ","));
        FileUtil.writeListToFile(FILE, list);
    }

    // ============================================================
    // PENDING RECIPIENTS CRUD   (unchanged)
    // ============================================================
    public void addPendingRecipient(Recipient r) {
        List<String> list = FileUtil.readFileToList(PENDING_FILE);
        list.add(toCSV(r));
        FileUtil.writeListToFile(PENDING_FILE, list);
    }

    public List<Recipient> getPendingRecipients() {
        List<Recipient> list = new ArrayList<>();
        for (String s : FileUtil.readFileToList(PENDING_FILE)) {
            list.add(fromCSV(s));
        }
        return list;
    }

    // Helper for screens
    public Recipient getRecipientFromPending(String id) {
        for (String line : FileUtil.readFileToList(PENDING_FILE)) {
            if (line.startsWith(id + ",")) {
                return fromCSV(line);
            }
        }
        return null;
    }

    // ============================================================
    // APPROVAL + REJECTION (logging added, donor-style)
    // ============================================================
    public void approveRecipient(Recipient r, String adminUsername) {

        // Remove from pending
        List<String> pending = FileUtil.readFileToList(PENDING_FILE);
        pending.removeIf(line -> line.startsWith(r.getId() + ","));
        FileUtil.writeListToFile(PENDING_FILE, pending);

        // Add to approved list
        addRecipient(r);

        // Log
        new LogService().addLog(new LogEntry(
            adminUsername,
            "APPROVE RECIPIENT",
            "Recipient ID: " + r.getId() + ", Name: " + r.getName()
        ));
    }

    public void rejectPendingRecipient(String recipientId, String adminUsername) {

        String name = "";
        for (String line : FileUtil.readFileToList(PENDING_FILE)) {
            if (line.startsWith(recipientId + ",")) {
                name = fromCSV(line).getName();
                break;
            }
        }

        // Remove from pending
        List<String> pending = FileUtil.readFileToList(PENDING_FILE);
        pending.removeIf(line -> line.startsWith(recipientId + ","));
        FileUtil.writeListToFile(PENDING_FILE, pending);

        // Log
        new LogService().addLog(new LogEntry(
            adminUsername,
            "REJECT RECIPIENT",
            "Recipient ID: " + recipientId + ", Name: " + name
        ));
    }
}

