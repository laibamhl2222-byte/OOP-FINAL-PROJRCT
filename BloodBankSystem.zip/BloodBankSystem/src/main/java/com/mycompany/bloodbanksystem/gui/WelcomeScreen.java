package com.mycompany.bloodbanksystem.gui;

import javax.swing.*;
import java.awt.*;

public class WelcomeScreen extends JFrame {

    public WelcomeScreen() {
        setTitle("Blood Bank System");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient background
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(220, 53, 69); // red
                Color color2 = new Color(255, 102, 102); // light red
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        add(panel);

         // Title panel to hold title + subtitle
         JPanel titlePanel = new JPanel();
         titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
         titlePanel.setOpaque(false);
         titlePanel.setAlignmentX(Component.CENTER_ALIGNMENT);

         // Main title
         JLabel title = new JLabel("WELCOME TO BLOOD BANK SYSTEM", SwingConstants.CENTER);
         title.setAlignmentX(Component.CENTER_ALIGNMENT);
         title.setFont(new Font("Tahoma", Font.BOLD, 26));
         title.setForeground(Color.WHITE);

         // Subtitle
         JLabel subtitle1 = new JLabel("An advanced system to efficiently match donors and recipients", SwingConstants.CENTER);
         subtitle1.setAlignmentX(Component.CENTER_ALIGNMENT);
         subtitle1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
         subtitle1.setForeground(Color.WHITE);

         JLabel subtitle2 = new JLabel("Helping save lives by connecting donors to patients", SwingConstants.CENTER);
         subtitle2.setAlignmentX(Component.CENTER_ALIGNMENT);
         subtitle2.setFont(new Font("Times New Roman", Font.PLAIN, 16));
         subtitle2.setForeground(Color.WHITE);

        // Add both to title panel
        titlePanel.add(title);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 10)));
        titlePanel.add(subtitle1);
        titlePanel.add(Box.createRigidArea(new Dimension(0, 10)));
        titlePanel.add(subtitle2);

        // Add panel to main panel
        panel.add(titlePanel);

        panel.add(Box.createRigidArea(new Dimension(0, 80))); // spacing

        // Continue button
        JButton continueBtn = new JButton("Continue to proceed");
        continueBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        continueBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        continueBtn.setForeground(Color.RED);
        continueBtn.setBackground(new Color(255, 255, 255)); // White colour
        continueBtn.setFocusPainted(false);
        continueBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        continueBtn.setMaximumSize(new Dimension(250, 50));
continueBtn.setMinimumSize(new Dimension(250, 50));


        // Hover effect
        continueBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                continueBtn.setBackground(new Color(41, 128, 185)); // darker blue
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                continueBtn.setBackground(new Color(255, 255, 255)); // Again white
            }
        });

        continueBtn.addActionListener(e -> {
            dispose();
            new RoleSelectionScreen().setVisible(true);
        });

        panel.add(continueBtn);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new WelcomeScreen().setVisible(true);
        });
    }
}
