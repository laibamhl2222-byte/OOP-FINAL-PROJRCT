package com.mycompany.bloodbanksystem.service;

import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.util.FileUtil;

import java.util.ArrayList;
import java.util.List;

public class LogService {

    private final String FILE = "logs.txt";

    public void addLog(LogEntry log) {
        List<String> lines = FileUtil.readFileToList(FILE);
        lines.add(log.toCSV());
        FileUtil.writeListToFile(FILE, lines);
    }

    public List<LogEntry> getAllLogs() {
        List<LogEntry> list = new ArrayList<>();
        for (String line : FileUtil.readFileToList(FILE)) {
            list.add(LogEntry.fromCSV(line));
        }
        return list;
    }

    // Delete a log entry based on timestamp + action (or full CSV match)
    public void deleteLog(String timestamp, String action) {
        List<String> lines = FileUtil.readFileToList(FILE);
        // Remove lines where both timestamp and action match
        lines.removeIf(line -> line.contains(timestamp) && line.contains(action));
        FileUtil.writeListToFile(FILE, lines);
    }
}
