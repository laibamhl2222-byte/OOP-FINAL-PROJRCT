package com.mycompany.bloodbanksystem.model;

import java.time.LocalDateTime;
import java.util.UUID;

public class LogEntry {
    private String id;
    private String timestamp;
    private String user;    // username or admin name
    private String action;  // e.g., "ADD DONOR"
    private String details; // e.g., "Donor ID: D001"

    public LogEntry(String user, String action, String details) {
        this.id = UUID.randomUUID().toString();
        this.timestamp = LocalDateTime.now().toString();
        this.user = user;
        this.action = action;
        this.details = details;
    }

    // Getters
    public String getId() { return id; }
    public String getTimestamp() { return timestamp; }
    public String getUser() { return user; }
    public String getAction() { return action; }
    public String getDetails() { return details; }

    // Convert to CSV
    public String toCSV() {
        return id + "," + timestamp + "," + user + "," + action + "," + details.replace(",", ";");
    }

    // Parse from CSV
    public static LogEntry fromCSV(String line) {
        String[] a = line.split(",", 5);
        LogEntry log = new LogEntry(a[2], a[3], a[4]);
        log.id = a[0];
        log.timestamp = a[1];
        return log;
    }
}
