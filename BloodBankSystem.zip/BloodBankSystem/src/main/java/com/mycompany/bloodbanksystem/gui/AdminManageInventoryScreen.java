package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.InventoryItem;
import com.mycompany.bloodbanksystem.service.InventoryService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminManageInventoryScreen extends JFrame {

    private InventoryService inventoryService = new InventoryService();
    private DefaultTableModel model;
    private JTable table;
    private String adminUsername;

    public AdminManageInventoryScreen(String adminUsername) {
        this.adminUsername = adminUsername;

        setTitle("Manage Inventory");
        setSize(900, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = gradientPanel();
        panel.setLayout(new BorderLayout(10,10));
        panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        add(panel);

        JLabel title = new JLabel("Blood Inventory", SwingConstants.CENTER);
        title.setFont(new Font("Tahoma", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        panel.add(title, BorderLayout.NORTH);

        String[] cols = {"ID","Blood Group","Units","Added On","Notes"};
        model = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel bottom = new JPanel();
        bottom.setOpaque(false);
        JButton btnRefresh = new JButton("Refresh");
        JButton btnAdd = new JButton("Add Unit");
        JButton btnEdit = new JButton("Edit Selected");
        JButton btnDelete = new JButton("Delete Selected");
        style(btnRefresh); style(btnAdd); style(btnEdit); style(btnDelete);
        bottom.add(btnRefresh); bottom.add(btnAdd); bottom.add(btnEdit); bottom.add(btnDelete);
        panel.add(bottom, BorderLayout.SOUTH);

        loadInventory();

        btnRefresh.addActionListener(e -> loadInventory());

        btnAdd.addActionListener(e -> {
            InventoryEditDialog dlg = new InventoryEditDialog(this, null, adminUsername);
            dlg.setVisible(true);
            if (dlg.isSaved()) {
                // dialog already updated inventory with logging
                loadInventory();
            }
        });

        btnEdit.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r == -1) { JOptionPane.showMessageDialog(this,"Select a row"); return; }

            String id = (String) model.getValueAt(r,0);
            InventoryItem item = inventoryService.getById(id);

            InventoryEditDialog dlg = new InventoryEditDialog(this, item, adminUsername);
            dlg.setVisible(true);

            if (dlg.isSaved()) {
                // dialog already updated inventory with logging
                loadInventory();
            }
        });

        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r == -1) { JOptionPane.showMessageDialog(this,"Select a row"); return; }

            String id = (String) model.getValueAt(r,0);
            inventoryService.deleteItem(id, adminUsername); // logging-aware delete
            JOptionPane.showMessageDialog(this,"Deleted");
            loadInventory();
        });
    }

    private void loadInventory() {
        model.setRowCount(0);
        List<InventoryItem> list = inventoryService.getAll();
        for (InventoryItem i : list) {
            model.addRow(new Object[]{
                    i.getId(), i.getBloodGroup(), i.getUnits(), 
                    i.getAddedOn(), i.getNotes()
            });
        }
    }

    private JPanel gradientPanel() {
        return new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d=(Graphics2D)g;
                GradientPaint gp=new GradientPaint(
                        0,0,new Color(220,53,69),
                        0,getHeight(),new Color(255,102,102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0,0,getWidth(),getHeight());
            }
        };
    }

    private void style(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(231,76,60));
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(231,76,60)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Color fg = btn.getForeground();
                btn.setForeground(btn.getBackground());
                btn.setBackground(fg);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setForeground(Color.WHITE);
                btn.setBackground(new Color(231,76,60));
            }
        });
    }
}
