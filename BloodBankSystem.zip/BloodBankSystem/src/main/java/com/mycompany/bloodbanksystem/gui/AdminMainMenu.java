package com.mycompany.bloodbanksystem.gui;

import javax.swing.*;
import java.awt.*;

public class AdminMainMenu extends JFrame {

    public AdminMainMenu() {
        setTitle("Admin Main Menu");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblTitle = new JLabel("Admin Dashboard");
        lblTitle.setBounds(150, 20, 200, 30);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        add(lblTitle);

        JButton btnDonor = new JButton("Manage Donors");
        btnDonor.setBounds(150, 80, 200, 40);
        add(btnDonor);

        JButton btnRecipient = new JButton("Manage Recipients");
        btnRecipient.setBounds(150, 140, 200, 40);
        add(btnRecipient);

        JButton btnInventory = new JButton("Manage Inventory");
        btnInventory.setBounds(150, 200, 200, 40);
        add(btnInventory);

        JButton btnReports = new JButton("View Reports");
        btnReports.setBounds(150, 260, 200, 40);
        add(btnReports);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBounds(150, 320, 200, 40);
        add(btnLogout);

        // Actions (placeholders - link to actual CRUD screens later)
        btnDonor.addActionListener(e -> JOptionPane.showMessageDialog(this, "Donor Management Clicked"));
        btnRecipient.addActionListener(e -> JOptionPane.showMessageDialog(this, "Recipient Management Clicked"));
        btnInventory.addActionListener(e -> JOptionPane.showMessageDialog(this, "Inventory Management Clicked"));
        btnReports.addActionListener(e -> JOptionPane.showMessageDialog(this, "Reports Clicked"));
        btnLogout.addActionListener(e -> {
            dispose();
            new WelcomeScreen().setVisible(true);
        });
    }
}