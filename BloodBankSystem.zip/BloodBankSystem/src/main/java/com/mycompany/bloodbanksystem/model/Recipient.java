package com.mycompany.bloodbanksystem.model;

public class Recipient extends User {

    private String requiredBloodGroup;
    private String urgency;

    public Recipient() {}

    public Recipient(String id, String name, int age, String gender, String contact,
                     String username, String password,
                     String requiredBloodGroup, String urgency) {

        super(id, name, age, gender, contact, username, password);
        this.requiredBloodGroup = requiredBloodGroup;
        this.urgency = urgency;
    }

    // Getters & Setters
    public String getRequiredBloodGroup() { return requiredBloodGroup; }
    public void setRequiredBloodGroup(String requiredBloodGroup) { this.requiredBloodGroup = requiredBloodGroup; }

    public String getUrgency() { return urgency; }
    public void setUrgency(String urgency) { this.urgency = urgency; }
}