package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;

import javax.swing.*;
import java.awt.*;

public class DonorViewScreen extends JFrame {

    public DonorViewScreen(Donor donor) {
        setTitle("View Donor Profile");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        add(panel);

        JLabel title = new JLabel("Donor Profile");
        title.setFont(new Font("Tahoma", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        JTextArea info = new JTextArea(
                "Name: " + donor.getName() +
                "\nAge: " + donor.getAge() +
                "\nGender: " + donor.getGender() +
                "\nContact: " + donor.getContact() +
                "\nBlood Group: " + donor.getBloodGroup() +
                "\nMedical Status: " + donor.getMedicalStatus() +
                "\nLast Donation Date: " + donor.getLastDonationDate() +
                "\nEligible: " + (donor.isEligible() ? "Yes" : "No")
        );
        info.setFont(new Font("Tahoma", Font.PLAIN, 16));
        info.setEditable(false);
        info.setBackground(new Color(255, 255, 255, 200));
        info.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.add(info);
    }
}
