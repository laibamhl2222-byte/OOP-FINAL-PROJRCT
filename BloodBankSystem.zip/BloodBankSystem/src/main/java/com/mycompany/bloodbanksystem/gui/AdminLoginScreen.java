package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.service.AdminService;

import javax.swing.*;
import java.awt.*;

public class AdminLoginScreen extends JFrame {

    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private AdminService adminService = new AdminService();

    public AdminLoginScreen() {
        setTitle("Admin Login");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        add(panel);

        JLabel title = new JLabel("Admin Login");
        title.setFont(new Font("Tahoma", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 40)));

        txtUsername = new JTextField();
        txtPassword = new JPasswordField();

        panel.add(createFieldRow("Username", txtUsername));
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(createFieldRow("Password", txtPassword));
        panel.add(Box.createRigidArea(new Dimension(0, 40)));

        JButton btnLogin = new JButton("Login");
        styleButton(btnLogin);
        panel.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String username = txtUsername.getText();
            String password = new String(txtPassword.getPassword());
            if (adminService.validateLogin(username, password)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose();
                new AdminDashboard(username).setVisible(true); // create later
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JPanel createFieldRow(String labelText, JComponent field) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        row.setOpaque(false);

        JLabel label = new JLabel(labelText + ": ");
        label.setFont(new Font("Tahoma", Font.PLAIN, 16));
        label.setForeground(Color.WHITE);
        label.setPreferredSize(new Dimension(150, 30));

        field.setFont(new Font("Tahoma", Font.PLAIN, 16));
        field.setPreferredSize(new Dimension(200, 30));
        field.setMaximumSize(new Dimension(200, 30));

        row.add(label);
        row.add(Box.createRigidArea(new Dimension(20, 0)));
        row.add(field);

        return row;
    }

    private void styleButton(JButton btn) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(new Color(245, 245, 220));
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(200, 50));
        btn.setMaximumSize(new Dimension(200, 50));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(200, 50, 50)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(245, 245, 220)); }
        });
    }
}