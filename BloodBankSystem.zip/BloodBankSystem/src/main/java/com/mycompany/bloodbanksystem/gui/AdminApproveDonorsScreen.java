package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.service.DonorService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminApproveDonorsScreen extends JFrame {

    private DonorService donorService = new DonorService();
    private JTable table;
    private DefaultTableModel model;
    private String adminUsername; // store the admin who is logged in

    public AdminApproveDonorsScreen(String adminUsername) {
        this.adminUsername = adminUsername;

        setTitle("Approve Pending Donors");
        setSize(800, 500);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout());
        add(panel);

        String[] columns = {"ID", "Name", "Age", "Gender", "Contact", "Blood Group", "Medical Status", "Approve", "Reject"};
        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return col == 7 || col == 8; // Only Approve/Reject buttons editable
            }
        };
        table = new JTable(model);
        table.setRowHeight(30);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        loadPendingDonors();
    }

    private void loadPendingDonors() {
        List<Donor> pending = donorService.getPendingDonors();
        model.setRowCount(0);
        for (Donor d : pending) {
            model.addRow(new Object[]{
                    d.getId(),
                    d.getName(),
                    d.getAge(),
                    d.getGender(),
                    d.getContact(),
                    d.getBloodGroup(),
                    d.getMedicalStatus(),
                    "Approve",
                    "Reject"
            });
        }

        // Add button actions
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());
                if (row < 0) return;
                Donor d = pending.get(row);

                if (col == 7) { // Approve
                    donorService.approveDonor(d, adminUsername);
                    JOptionPane.showMessageDialog(null, "Donor approved!");
                    loadPendingDonors();
                } else if (col == 8) { // Reject
                    donorService.rejectPendingDonor(d.getId(), adminUsername);
                    JOptionPane.showMessageDialog(null, "Donor rejected!");
                    loadPendingDonors();
                }
            }
        });
    }
}
