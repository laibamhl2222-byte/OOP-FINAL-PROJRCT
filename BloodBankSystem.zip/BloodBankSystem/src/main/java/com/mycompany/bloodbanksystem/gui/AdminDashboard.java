package com.mycompany.bloodbanksystem.gui;

import javax.swing.*;
import java.awt.*;

public class AdminDashboard extends JFrame {

    private String adminUsername;

    public AdminDashboard(String adminUsername) {
        this.adminUsername = adminUsername;

        setTitle("Admin Dashboard");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = gradientPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 60, 30, 60));
        add(panel);

        JLabel title = new JLabel("Administrator Dashboard");
        title.setFont(new Font("Tahoma", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);
        panel.add(Box.createRigidArea(new Dimension(0, 30)));

        JPanel grid = new JPanel(new GridLayout(3, 3, 18, 18));
        grid.setOpaque(false);

        JButton btnApproveDonors = new JButton("Approve Donors");
        JButton btnApproveRecipients = new JButton("Approve Recipients");
        JButton btnManageInventory = new JButton("Manage Inventory");
        JButton btnViewDonors = new JButton("View All Donors");
        JButton btnViewRecipients = new JButton("View All Recipients");
        JButton btnViewLogs = new JButton("View Logs");
        JButton btnGenerateReports = new JButton("Generate Reports");
        JButton btnDeleteRecords = new JButton("Delete Records");
        JButton btnLogout = new JButton("Logout");

        styleButton(btnApproveDonors);
        styleButton(btnApproveRecipients);
        styleButton(btnManageInventory);
        styleButton(btnViewDonors);
        styleButton(btnViewRecipients);
        styleButton(btnViewLogs);
        styleButton(btnGenerateReports);
        styleButton(btnDeleteRecords);
        styleButton(btnLogout);

        grid.add(btnApproveDonors);
        grid.add(btnApproveRecipients);
        grid.add(btnManageInventory);
        grid.add(btnViewDonors);
        grid.add(btnViewRecipients);
        grid.add(btnViewLogs);
        grid.add(btnGenerateReports);
        grid.add(btnDeleteRecords);
        grid.add(btnLogout);

        panel.add(grid);

        // Actions with adminUsername passed
        btnApproveDonors.addActionListener(e ->
                new AdminApproveDonorsScreen(adminUsername).setVisible(true));

        btnApproveRecipients.addActionListener(e ->
                new AdminApproveRecipientsScreen(adminUsername).setVisible(true));
        
        btnManageInventory.addActionListener(e ->
                new AdminManageInventoryScreen(adminUsername).setVisible(true));

        btnViewDonors.addActionListener(e ->
                new AdminViewAllDonorsScreen().setVisible(true));

        btnViewRecipients.addActionListener(e ->
                new AdminViewAllRecipientsScreen().setVisible(true));
        
        btnViewLogs.addActionListener(e ->
                new AdminViewLogsScreen().setVisible(true));

        btnGenerateReports.addActionListener(e ->
                new AdminReportGenerationScreen().setVisible(true));

        btnDeleteRecords.addActionListener(e ->
                new AdminDeleteRecordsScreen(adminUsername).setVisible(true));
        

        btnLogout.addActionListener(e -> {
            dispose();
            new WelcomeScreen().setVisible(true);
        });
    }

    private JPanel gradientPanel() {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
    }

    private void styleButton(JButton btn) {
        Color bgColor = new Color(231, 76, 60);  // initial background
        Color fgColor = Color.WHITE;             // initial foreground

        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(fgColor);
        btn.setBackground(bgColor);
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(bgColor));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(fgColor);
                btn.setForeground(bgColor);
                btn.setBorder(BorderFactory.createLineBorder(fgColor));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(bgColor);
                btn.setForeground(fgColor);
                btn.setBorder(BorderFactory.createLineBorder(bgColor));
            }
        });
    }
}
