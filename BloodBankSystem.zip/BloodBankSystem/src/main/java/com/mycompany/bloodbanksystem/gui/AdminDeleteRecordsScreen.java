package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.model.InventoryItem;
import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.service.DonorService;
import com.mycompany.bloodbanksystem.service.InventoryService;
import com.mycompany.bloodbanksystem.service.LogService;
import com.mycompany.bloodbanksystem.service.RecipientService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class AdminDeleteRecordsScreen extends JFrame {

    private String adminUsername;
    private DonorService donorService = new DonorService();
    private RecipientService recipientService = new RecipientService();
    private InventoryService inventoryService = new InventoryService();
    private LogService logService = new LogService();

    private DefaultTableModel donorModel, recipientModel, inventoryModel, logModel;

    public AdminDeleteRecordsScreen(String adminUsername) {
        this.adminUsername = adminUsername;

        setTitle("Admin Delete Records");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Red-themed frame
        getContentPane().setBackground(new Color(255, 230, 230));

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Donors", createDonorPanel());
        tabs.addTab("Recipients", createRecipientPanel());
        tabs.addTab("Inventory", createInventoryPanel());
        tabs.addTab("Logs", createLogsPanel());

        add(tabs);
    }

    // -------------------- DONORS TAB --------------------
    private JPanel createDonorPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        donorModel = new DefaultTableModel(new String[]{"ID","Name","Blood Group","Contact"},0){
            @Override public boolean isCellEditable(int row, int column){ return false; }
        };
        JTable table = new JTable(donorModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected");
        styleButton(btnDelete);
        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if(r==-1){ JOptionPane.showMessageDialog(this,"Select a donor"); return; }
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this donor?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if(confirm != JOptionPane.YES_OPTION) return;

            String id = (String) donorModel.getValueAt(r,0);
            donorService.deleteDonor(id);
            JOptionPane.showMessageDialog(this,"Donor deleted");
            loadDonors();
        });

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnDelete);
        panel.add(bottom, BorderLayout.SOUTH);

        loadDonors();
        return panel;
    }

    private void loadDonors() {
        donorModel.setRowCount(0);
        List<Donor> list = donorService.getAllDonors();
        for(Donor d : list){
            donorModel.addRow(new Object[]{d.getId(), d.getName(), d.getBloodGroup(), d.getContact()});
        }
    }

    // -------------------- RECIPIENTS TAB --------------------
    private JPanel createRecipientPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        recipientModel = new DefaultTableModel(new String[]{"ID","Name","Blood Group","Contact"},0){
            @Override public boolean isCellEditable(int row,int col){ return false; }
        };
        JTable table = new JTable(recipientModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected");
        styleButton(btnDelete);
        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if(r==-1){ JOptionPane.showMessageDialog(this,"Select a recipient"); return; }
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this recipient?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if(confirm != JOptionPane.YES_OPTION) return;

            String id = (String) recipientModel.getValueAt(r,0);
            recipientService.deleteRecipient(id);
            JOptionPane.showMessageDialog(this,"Recipient deleted");
            loadRecipients();
        });

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnDelete);
        panel.add(bottom, BorderLayout.SOUTH);

        loadRecipients();
        return panel;
    }

    private void loadRecipients() {
        recipientModel.setRowCount(0);
        List<Recipient> list = recipientService.getAllRecipients();
        for(Recipient r : list){
            recipientModel.addRow(new Object[]{r.getId(), r.getName(), r.getRequiredBloodGroup(), r.getContact()});
        }
    }

    // -------------------- INVENTORY TAB --------------------
    private JPanel createInventoryPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        inventoryModel = new DefaultTableModel(new String[]{"ID","Blood Group","Units","Notes"},0){
            @Override public boolean isCellEditable(int row,int col){ return false; }
        };
        JTable table = new JTable(inventoryModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected");
        styleButton(btnDelete);
        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if(r==-1){ JOptionPane.showMessageDialog(this,"Select an inventory item"); return; }
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this inventory item?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if(confirm != JOptionPane.YES_OPTION) return;

            String id = (String) inventoryModel.getValueAt(r,0);
            inventoryService.deleteItem(id, adminUsername);
            JOptionPane.showMessageDialog(this,"Inventory item deleted");
            loadInventory();
        });

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnDelete);
        panel.add(bottom, BorderLayout.SOUTH);

        loadInventory();
        return panel;
    }

    private void loadInventory() {
        inventoryModel.setRowCount(0);
        List<InventoryItem> list = inventoryService.getAll();
        for(InventoryItem i : list){
            inventoryModel.addRow(new Object[]{i.getId(), i.getBloodGroup(), i.getUnits(), i.getNotes()});
        }
    }

    // -------------------- LOGS TAB --------------------
    private JPanel createLogsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        logModel = new DefaultTableModel(new String[]{"Timestamp","Admin","Action","Details"},0){
            @Override public boolean isCellEditable(int row,int col){ return false; }
        };
        JTable table = new JTable(logModel);
        table.setRowHeight(28);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);

        JButton btnDelete = new JButton("Delete Selected");
        styleButton(btnDelete);
        btnDelete.addActionListener(e -> {
            int r = table.getSelectedRow();
            if(r==-1){ JOptionPane.showMessageDialog(this,"Select a log entry"); return; }
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this log?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if(confirm != JOptionPane.YES_OPTION) return;

            String timestamp = (String) logModel.getValueAt(r,0);
            String action = (String) logModel.getValueAt(r,2);

            logService.deleteLog(timestamp, action);
            JOptionPane.showMessageDialog(this,"Log entry deleted");
            loadLogs();
        });

        JPanel bottom = new JPanel();
        bottom.setBackground(new Color(255, 230, 230));
        bottom.add(btnDelete);
        panel.add(bottom, BorderLayout.SOUTH);

        loadLogs();
        return panel;
    }

    private void loadLogs() {
        logModel.setRowCount(0);
        List<LogEntry> logs = logService.getAllLogs();
        for(LogEntry l : logs){
            logModel.addRow(new Object[]{
                    l.getTimestamp() != null ? l.getTimestamp() : "",
                    l.getUser() != null ? l.getUser() : "",
                    l.getAction() != null ? l.getAction() : "",
                    l.getDetails() != null ? l.getDetails() : ""
            });
        }
    }

    // -------------------- BUTTON STYLING --------------------
    private void styleButton(JButton btn) {
        btn.setFont(new Font("Tahoma", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(231,76,60));
        btn.setOpaque(true);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(new Color(231,76,60)));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Color fg = btn.getForeground();
                btn.setForeground(btn.getBackground());
                btn.setBackground(fg);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setForeground(Color.WHITE);
                btn.setBackground(new Color(231,76,60));
            }
        });
    }
}
