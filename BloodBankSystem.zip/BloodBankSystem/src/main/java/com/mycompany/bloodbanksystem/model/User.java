package com.mycompany.bloodbanksystem.model;

public class User {
    protected String id;
    protected String name;
    protected int age;
    protected String gender;
    protected String contact;
    protected String username;
    protected String password;

    public User() {}

    public User(String id, String name, int age, String gender,
                String contact, String username, String password) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.contact = contact;
        this.username = username;
        this.password = password;
    }

    // Getter & Setter Methods
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getContact() { return contact; }
    public void setContact(String contact) { this.contact = contact; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    // Authentication Method
    public boolean authenticate(String user, String pass) {
        return this.username.equals(user) && this.password.equals(pass);
    }
}