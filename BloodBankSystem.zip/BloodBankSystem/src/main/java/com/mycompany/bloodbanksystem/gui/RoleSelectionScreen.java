package com.mycompany.bloodbanksystem.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RoleSelectionScreen extends JFrame {

    public RoleSelectionScreen() {
        setTitle("Select Role");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient background
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(220, 53, 69); // red
                Color color2 = new Color(255, 102, 102); // light red
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        add(panel);

        // Title
        JLabel label = new JLabel("Select your role from the following:");
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        label.setFont(new Font("Tahoma", Font.BOLD, 20));
        label.setForeground(Color.WHITE);
        panel.add(label);

        panel.add(Box.createRigidArea(new Dimension(0, 80)));

        // Admin button
        JButton adminBtn = new JButton("Admin");
        styleButton(adminBtn, new Color(255, 255, 255)); // white colour button
        adminBtn.addActionListener(e -> {
            dispose();
            new AdminLoginScreen().setVisible(true);
        });
        panel.add(adminBtn);
        panel.add(Box.createRigidArea(new Dimension(0, 30))); // spacing

        // User button
        JButton userBtn = new JButton("User");
        styleButton(userBtn, new Color(255, 255, 255)); // white colour button
        userBtn.addActionListener(e -> {
            dispose();
            new UserTypeScreen().setVisible(true);
        });
        panel.add(userBtn);
    }

    private void styleButton(JButton button, Color color) {
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setFont(new Font("Tahoma", Font.BOLD, 18));
        button.setForeground(Color.RED);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(250, 60));
        button.setMaximumSize(new Dimension(250, 60));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(color.darker());
            }
            public void mouseExited(MouseEvent evt) {
                button.setBackground(color);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RoleSelectionScreen().setVisible(true));
    }
}