package com.mycompany.bloodbanksystem.gui;

import com.mycompany.bloodbanksystem.model.Recipient;
import com.mycompany.bloodbanksystem.service.RecipientService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class RecipientLoginScreen extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private RecipientService recipientService = new RecipientService();

    public RecipientLoginScreen() {
        setTitle("Recipient Login");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Gradient Panel
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(220, 53, 69),
                        0, getHeight(), new Color(255, 102, 102)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(50, 60, 50, 60));
        add(panel);

        // Title
        JLabel title = new JLabel("Recipient Login");
        title.setFont(new Font("Tahoma", Font.BOLD, 26));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(title);

        panel.add(Box.createRigidArea(new Dimension(0, 40)));

        // Username Field Row
        usernameField = new JTextField();
        panel.add(createFieldRow("Username", usernameField));
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Password Field Row
        passwordField = new JPasswordField();
        panel.add(createFieldRow("Password", passwordField));
        panel.add(Box.createRigidArea(new Dimension(0, 40)));

        // Login Button
        JButton loginBtn = new JButton("Login");
        styleButton(loginBtn, new Color(245, 245, 220)); // beige
        panel.add(loginBtn);

        loginBtn.addActionListener(e -> login());
    }
// Helper — label and field in one row
    private JPanel createFieldRow(String label, JComponent field) {
        JPanel row = new JPanel();
        row.setLayout(new BoxLayout(row, BoxLayout.X_AXIS));
        row.setOpaque(false);

        JLabel lbl = new JLabel(label + ": ");
        lbl.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lbl.setForeground(Color.WHITE);

        field.setPreferredSize(new Dimension(200, 35));
        field.setMaximumSize(new Dimension(250, 35));
        field.setFont(new Font("Tahoma", Font.PLAIN, 16));

        row.add(lbl);
        row.add(Box.createRigidArea(new Dimension(20, 0)));
        row.add(field);

        return row;
    }

    private void styleButton(JButton btn, Color color) {
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.setFont(new Font("Tahoma", Font.BOLD, 18));
        btn.setForeground(Color.RED);
        btn.setBackground(color);
        btn.setOpaque(true);
        btn.setPreferredSize(new Dimension(250, 60));
        btn.setMaximumSize(new Dimension(250, 60));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setFocusPainted(false);

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(color.darker()); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(color); }
        });
    }
    
    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        List<Recipient> recipients = recipientService.getAllRecipients();
        
        for (Recipient r : recipients) {
            if (r.getUsername().equals(username) && r.getPassword().equals(password)) {
                JOptionPane.showMessageDialog(this, "Login Successful!");
                dispose();
                new RecipientMenu(r).setVisible(true);
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Invalid username or password!", "Error", JOptionPane.ERROR_MESSAGE);
        
    }
}