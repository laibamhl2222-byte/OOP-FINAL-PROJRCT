package com.mycompany.bloodbanksystem.service;

import com.mycompany.bloodbanksystem.util.FileUtil;
import com.mycompany.bloodbanksystem.model.Admin;

import java.util.*;

public class AdminService {

    private final String FILE = "admins.txt";

    // Convert Admin → CSV
    private String toCSV(Admin a) {
        return a.getId() + "," + a.getName() + "," + a.getAge() + "," +
               a.getGender() + "," + a.getContact() + "," +
               a.getUsername() + "," + a.getPassword();
    }

    // Convert CSV → Admin
    private Admin fromCSV(String line) {
        String[] a = line.split(",");
        return new Admin(
            a[0], a[1], Integer.parseInt(a[2]), a[3], a[4], a[5], a[6]
        );
    }

    // Add admin (optional)
    public void addAdmin(Admin a) {
        List<String> list = FileUtil.readFileToList(FILE);
        list.add(toCSV(a));
        FileUtil.writeListToFile(FILE, list);
    }

    // Validate login
    public boolean validateLogin(String username, String password) {
        for (String line : FileUtil.readFileToList(FILE)) {
            Admin a = fromCSV(line);
            if (a.authenticate(username, password)) {
                return true;
            }
        }
        return false;
    }

    // Get all admins (needed for checking if default exists)
    public List<Admin> getAllAdmins() {
        List<Admin> admins = new ArrayList<>();
        for (String line : FileUtil.readFileToList(FILE)) {
            admins.add(fromCSV(line));
        }
        return admins;
    }
}
