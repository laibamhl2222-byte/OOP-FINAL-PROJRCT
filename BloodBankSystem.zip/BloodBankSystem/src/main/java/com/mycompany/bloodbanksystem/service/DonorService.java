package com.mycompany.bloodbanksystem.service;

import com.mycompany.bloodbanksystem.model.Donor;
import com.mycompany.bloodbanksystem.model.LogEntry;
import com.mycompany.bloodbanksystem.util.FileUtil;
import com.mycompany.bloodbanksystem.service.LogService;

import java.util.*;

public class DonorService {

    private final String FILE = "donors.txt";             // Approved donors
    private final String PENDING_FILE = "pending_donors.txt"; // Pending donors

    // ------------------- CSV Conversion -------------------
    // Donor object → CSV
    private String donorToCSV(Donor d) {
        return d.getId() + "," + d.getName() + "," + d.getAge() + "," +
               d.getGender() + "," + d.getContact() + "," +
               d.getUsername() + "," + d.getPassword() + "," +
               d.getBloodGroup() + "," + d.getMedicalStatus() + "," +
               d.getLastDonationDate() + "," + d.isEligible();
    }

    // CSV → Donor object (public for reuse)
    public Donor csvToDonor(String line) {
        String[] a = line.split(",");
        return new Donor(
            a[0], a[1], Integer.parseInt(a[2]), a[3], a[4],
            a[5], a[6], a[7], a[8], a[9], Boolean.parseBoolean(a[10])
        );
    }

    // ------------------- APPROVED DONORS -------------------
    public void addDonor(Donor donor) {
    List<String> list = FileUtil.readFileToList(FILE);
    list.add(donorToCSV(donor));
    FileUtil.writeListToFile(FILE, list);
}

    public List<Donor> getAllDonors() {
        List<Donor> donors = new ArrayList<>();
        for (String line : FileUtil.readFileToList(FILE)) {
            donors.add(csvToDonor(line));
        }
        return donors;
    }

    public void updateDonor(Donor updated) {
        List<String> list = FileUtil.readFileToList(FILE);
        List<String> newList = new ArrayList<>();

        for (String line : list) {
            Donor d = csvToDonor(line);
            if (d.getId().equals(updated.getId())) {
                newList.add(donorToCSV(updated));
            } else {
                newList.add(line);
            }
        }

        FileUtil.writeListToFile(FILE, newList);
    }

    public void deleteDonor(String donorId) {
        List<String> list = FileUtil.readFileToList(FILE);
        list.removeIf(line -> line.startsWith(donorId + ","));
        FileUtil.writeListToFile(FILE, list);
    }

    // ------------------- PENDING DONORS -------------------
    public void addPendingDonor(Donor donor) {
        List<String> list = FileUtil.readFileToList(PENDING_FILE);
        list.add(donorToCSV(donor));
        FileUtil.writeListToFile(PENDING_FILE, list);
    }

    public List<Donor> getPendingDonors() {
        List<Donor> pending = new ArrayList<>();
        for (String line : FileUtil.readFileToList(PENDING_FILE)) {
            pending.add(csvToDonor(line));
        }
        return pending;
    }

    public void approveDonor(Donor donor, String adminUsername) {
        // Remove from pending
        List<String> pending = FileUtil.readFileToList(PENDING_FILE);
        pending.removeIf(line -> line.startsWith(donor.getId() + ","));
        FileUtil.writeListToFile(PENDING_FILE, pending);

        // Add to approved donors
        addDonor(donor);
        
        // Log action
    if (adminUsername != null && !adminUsername.isEmpty()) {
        new LogService().addLog(
            new LogEntry(adminUsername, "APPROVE DONOR", "Donor ID: " + donor.getId())
        );
    }
    
    }

    public void rejectPendingDonor(String donorId, String adminUsername) {
        List<String> pending = FileUtil.readFileToList(PENDING_FILE);
        pending.removeIf(line -> line.startsWith(donorId + ","));
        FileUtil.writeListToFile(PENDING_FILE, pending);
        
        // Log rejection
    if (adminUsername != null && !adminUsername.isEmpty()) {
        new LogService().addLog(
            new LogEntry(adminUsername, "REJECT DONOR", "Donor ID: " + donorId)
        );
    }
    }

    // ------------------- SEARCH & BLOOD MATCH -------------------
    public List<Donor> searchByBloodGroup(String requiredGroup) {
        List<Donor> result = new ArrayList<>();
        List<Donor> donors = getAllDonors();

        for (Donor d : donors) {
            if (isCompatible(requiredGroup, d.getBloodGroup())) {
                result.add(d);
            }
        }
        return result;
    }

    private boolean isCompatible(String req, String donor) {
        // Extract base blood groups only (ignore +/-)
        String reqBase = req.replaceAll("[+-]", "");
        String donorBase = donor.replaceAll("[+-]", "");

        return switch (reqBase) {
            case "O" -> donorBase.equals("O");
            case "A" -> donorBase.equals("A") || donorBase.equals("O");
            case "B" -> donorBase.equals("B") || donorBase.equals("O");
            case "AB" -> true; // universal recipient
            default -> false;
        };
    }
}
