package com.mycompany.bloodbanksystem.util;

import java.io.*;
import java.util.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtil {

    // Write list of strings to file
    public static void writeListToFile(String fileName, List<String> dataList) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            for (String line : dataList) {
                bw.write(line);
                bw.newLine();
            }
        } catch (Exception e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    // Read file and return list of strings
    public static List<String> readFileToList(String fileName) {
        List<String> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return list;
    }
    
    // Write a single string to a file (overwrites existing)
    public static void writeStringToFile(String fileName, String content) {
        try {
            Files.writeString(Paths.get(fileName), content);
        } catch (Exception e) {
            System.out.println("Error writing string to file: " + e.getMessage());
        }
    }
}