package com.mycompany.bloodbanksystem.model;

import java.time.LocalDate;

public class InventoryItem {

    private String id;
    private String bloodGroup;
    private int units;
    private String addedOn;
    private String notes;

    public InventoryItem(String id, String bloodGroup, int units, String addedOn, String notes) {
        this.id = id;
        this.bloodGroup = bloodGroup;
        this.units = units;
        this.addedOn = addedOn;
        this.notes = notes;
    }

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public int getUnits() { return units; }
    public void setUnits(int units) { this.units = units; }

    public String getAddedOn() { return addedOn; }
    public void setAddedOn(String addedOn) { this.addedOn = addedOn; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
